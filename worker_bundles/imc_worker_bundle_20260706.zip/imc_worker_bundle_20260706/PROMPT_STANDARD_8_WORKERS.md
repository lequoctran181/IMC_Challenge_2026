Tôi đã gửi cho bạn toàn bộ repository chứa toàn bộ lịch sử các lần nộp của tôi, hiện tại đã có hơn 596 lần nộp. Bạn có thể kiểm tra nhé, ở trong thư mục: https://github.com/lequoctran181/IMC_Challenge_2026
Hãy C++ code cho tôi bài này nhé. Hãy cố gắng hết sức có thể, và đạt được điểm cao nhất, tối đa có thể nhé. Mục tiêu của tôi là top 1 về điểm số trên bảng xếp hạng nhé. Hãy gửi lại tôi file để tôi có thể submit sau khi bạn đã suy nghĩ xong nhé. Tôi đã gửi bạn tất cả các file cần thiết nhé.

Hiện tại, đã có những clarification sau:
Problem simplifygeometry
2026-06-18 20:11:15 Is the use of AI-generated code from LLMs (ChatGPT, Claude, ...) permitted for this challenge?
Reply to all teams
2026-06-18 22:04:07 You can use AI tools, freely to solve this problem.

Problem simplifygeometry
2026-06-18 21:29:33 In Symmetric Hausdorff distance, there is the formula d(M,M') given. Do a in M and b in M' only vary across vertices, or do they vary across all points including the interior surface points?
Reply to all teams
2026-06-18 21:51:54 In the formula, a and b vary across vertices of their respective mesh. We do not iterate over interior or surface points.

Problem simplifygeometry
2026-06-20 22:28:43 Are the current test cases final, or will additional tests be run after the contest ends? In other words, will the scoreboard at the end of the contest be final, or is there a post-contest rejudging phase?
Reply to all teams
2026-06-22 16:51:07 The current test cases are final, and there will be no rejudging phase after the contest.

Dưới đây là bảng xếp hạng đến hiện tại nhé, đây là top 3 đội cùng với điểm số của họ. Bài này điểm số max là 100 điểm:
1. Time for the Moon Night: 91.46
2. Nuggie: 91.39
3. SPBU-AMCP: 91.27

Tôi đã cung cấp cho bạn tất cả các thông tin cần thiết để bạn đạt được điểm cao nhất có thể và độc chiếm vị trí top 1. Hãy bắt đầu nhé. Mục tiêu chỉ được coi là hoàn thành khi tôi đã đạt được số điểm đứng ở vị trí top 1 nhé.

Cách đọc các file trong Github: submission_[số thứ tự submission]_[số điểm làm tròn 2 chữ số thập phân]_[số test case accepted trong tổng số 7 test cases]. Solution hiện tại cao nhất mới đạt 81.93 điểm và đã accepted đủ 7 test cases, nhưng vẫn thấp hơn rất xa mốc 91.80+. Nhớ rõ mục tiêu nhé.

Các submission có thể được upload lên Github tiếp kể cả khi bạn đang nghĩ nhé. Tôi có submission mới tôi sẽ upload luôn.
Tôi sẽ cập nhật cho bạn tình hình các submissions cá nhân hiện tại: score hiện tại của tôi là 81.93, rank 47, best file là current_best_81.93_submission_596.cpp trong bundle này. Mục tiêu cuối cùng vẫn là 91.80+ điểm, vượt top 1.

Bạn phải suy nghĩ thật lâu ở chế độ Pro Extended. Chỉ gửi lại một file C++17 hoàn chỉnh, không commit vào repo. Nếu dùng current_best làm nền, hãy trả về full source đã sửa, không chỉ patch.
