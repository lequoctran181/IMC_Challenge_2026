# IMC simplifygeometry current status - 2026-07-06

Repository: https://github.com/lequoctran181/IMC_Challenge_2026

Contest problem: simplifygeometry, Problem B.

Current personal best:
- Team: NEU.AddictedTribes
- Score: 81.93
- All 7 test cases accepted
- Latest best file in this bundle: current_best_81.93_submission_596.cpp
- Latest repository history is up to at least submission_596_81.93_7.cpp

Current leaderboard snapshot verified on Kattis on 2026-07-06:
- Rank 1: Time for the Moon Night, 91.46
- Rank 2: Nuggie, 91.39
- Rank 3: SPBU-AMCP, 91.27
- Goal for this worker: produce a C++17 solution that can realistically exceed 91.80.

Important clarifications:
- AI-generated code is allowed.
- In symmetric Hausdorff distance, points a in M and b in M' range over vertices only, not surface interiors.
- Current public test cases are final; there is no post-contest rejudge.

File naming convention in the repository:
- submission_[submission number]_[score rounded to 2 decimals]_[accepted test cases out of 7].cpp
- CE is used for compile errors.

What is needed:
- Do not return analysis only. Return a complete C++ source file.
- Preserve validity: closed manifold, non-degenerate faces, valid indices, symmetric vertex Hausdorff <= 5% AABB diagonal, FinalSSIM >= 0.9.
- The current 81.93 plateau already contains many local collapses and patch passes. A useful breakthrough likely needs a new structural recognizer, stronger case routing, or a safer but much more aggressive special-case replacement for one or more hidden/final meshes.
- If you modify current_best_81.93_submission_596.cpp, explain exactly which region/heuristic changed and why it should improve score without losing accepted cases.
