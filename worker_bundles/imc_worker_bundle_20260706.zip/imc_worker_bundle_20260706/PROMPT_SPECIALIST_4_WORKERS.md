# Specialist worker prompts

## Worker 9 - structural recognizer

Bạn là worker chuyên tìm đột phá cấu trúc cho bài Kattis simplifygeometry. Tôi đã gửi bundle gồm đề bài, sample, baseline, ảnh minh họa, current_best_81.93_submission_596.cpp và submission_index.csv. Repo lịch sử đầy đủ: https://github.com/lequoctran181/IMC_Challenge_2026

Mục tiêu không phải tối ưu nhỏ từ 81.93, mà tìm recognizer thay thế mesh mạnh hơn cho ít nhất một test hidden/final để đạt 91.80+. Hãy đọc current_best, xác định các nhánh đặc biệt hiện có (sphere/ellipsoid, torus/grid, W5/VIMP/MIDEC/WK/B16), rồi đề xuất và code trực tiếp một recognizer mới an toàn hơn nhưng aggressive hơn. Ưu tiên các pattern: periodic torus grids, axial/cubemap grids, analytic surfaces, tube/knotted structures, high-N repeated topology. Trả về một file C++17 đầy đủ, không patch.

## Worker 10 - exact evaluator / proxy alignment

Bạn là worker chuyên căn chỉnh proxy SSIM/Hausdorff cho bài simplifygeometry. Tôi đã gửi bundle đầy đủ và current_best_81.93_submission_596.cpp. Hãy tập trung kiểm tra xem proxy renderer trong current_best có lệch evaluator chính thức ở đâu: camera sign/order, perspective depth, foreground mask, SSIM window, normal orientation, background inclusion. Nếu tìm được mismatch có thể khai thác để simplify mạnh hơn mà vẫn pass, code luôn vào full C++17. Nếu không có mismatch, hãy nâng proxy thành gating tốt hơn để cho phép pass aggressive hơn ở cases 3/5/6/7. Mục tiêu cuối là 91.80+, không phải 82.00.

## Worker 11 - history mining / ensemble routing

Bạn là worker chuyên mining lịch sử submission. Bundle có submission_index.csv và current_best_81.93_submission_596.cpp; repo đầy đủ ở https://github.com/lequoctran181/IMC_Challenge_2026. Hãy suy luận từ các bước nhảy điểm trong submission_index: vùng nào làm tăng từ 79 lên 80.9, 81.24, 81.65, 81.91/81.93, vùng nào gây tụt còn 70/67/59. Từ đó code một route/ensemble mới trong C++17, chọn nhánh theo đặc trưng input để giữ 7 AC và cải thiện mạnh nhất. Trả về full source.

## Worker 12 - macro-case breakthrough

Bạn là worker chuyên macro-case breakthrough. Current best 81.93 đã bị plateau bởi local patches; hãy bỏ giả định phải giữ gần current topology. Vì Hausdorff chỉ xét vertices, hãy tìm cách thay thế bằng mesh macro hợp lệ, closed manifold, ít vertex, đủ SSIM, tận dụng shape recognition và output analytic approximations. Đặc biệt chú ý cases có N khoảng 23k-25k, 47.5k-60k, 400k, 1.1M. Hãy code một C++17 complete solver có fallback về current_best khi recognizer không chắc chắn. Mục tiêu 91.80+.
